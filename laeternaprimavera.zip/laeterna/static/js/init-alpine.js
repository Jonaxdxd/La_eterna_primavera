function data() {

  function getThemeFromLocalStorage() {
    // if user already changed the theme, use it
    if (window.localStorage.getItem('dark')) {
      return JSON.parse(window.localStorage.getItem('dark'))
    }

    // else return their preferences
    return (
      !!window.matchMedia &&
      window.matchMedia('(prefers-color-scheme: dark)').matches
    )
  }

  function setThemeToLocalStorage(value) {
    window.localStorage.setItem('dark', value)
  }

  return {
    dark: getThemeFromLocalStorage(),
    toggleTheme() {
      this.dark = !this.dark
      setThemeToLocalStorage(this.dark)
    },
    isSideMenuOpen: false,
    toggleSideMenu() {
      this.isSideMenuOpen = !this.isSideMenuOpen
    },
    closeSideMenu() {
      this.isSideMenuOpen = false
    },
    isNotificationsMenuOpen: false,
    toggleNotificationsMenu() {
      this.isNotificationsMenuOpen = !this.isNotificationsMenuOpen
    },
    closeNotificationsMenu() {
      this.isNotificationsMenuOpen = false
    },
    isProfileMenuOpen: false,
    toggleProfileMenu() {
      this.isProfileMenuOpen = !this.isProfileMenuOpen
    },
    closeProfileMenu() {
      this.isProfileMenuOpen = false
    },
    isPagesMenuOpen: false,
    togglePagesMenu() {
      this.isPagesMenuOpen = !this.isPagesMenuOpen
    },

    // Modal Pacientes
    isModalOpen: false,
    trapCleanup: null,
    formData: {},
    async openModal(idpaciente) {
      this.isModalOpen = true
      const response = await fetch(`/api/paciente/${idpaciente}`);
      const pacienteData = await response.json();
      this.formData = pacienteData;
      this.formData.idpaciente = idpaciente;

      const form = document.getElementById('editarPacienteForm');
      form.action = `/editarPaciente/${idpaciente}`;
    },
    closeModal() {
      this.isModalOpen = false
      this.trapCleanup()
    },

    // Modal Médicos
    isModalMedOpen: false,
    trapCleanup: null,
    formMedData: {},
    async openModalMed(idmedico) {
      this.isModalMedOpen = true
      const response = await fetch(`/api/medico/${idmedico}`);
      const pacienteData = await response.json();
      this.formMedData = pacienteData;
      this.formMedData.idmedico = idmedico;

      const form = document.getElementById('editarMedicoForm');
      form.action = `/editarMedico/${idmedico}`;
    },
    closeModalMed() {
      this.isModalMedOpen = false
      this.trapCleanup()
    },

    // Modal Diagnosticos
    isModalDiagOpen: false,
    trapCleanup: null,
    formDiagData: {},
    async openModalDiag(iddiagnostico) {
      this.isModalDiagOpen = true
      const response = await fetch(`/api/diagnostico/${iddiagnostico}`);
      const diagnosticoData = await response.json();
      this.formDiagData = diagnosticoData;
      this.formDiagData.iddiagnostico = iddiagnostico;

      const form = document.getElementById('editarDiagForm');
      form.action = `/editarDiagnostico/${iddiagnostico}`;
    },
    closeModalDiag() {
      this.isModalDiagOpen = false
      this.trapCleanup()
    },

    // Modal Receta Médica
    isModalRecMedOpen: false,
    trapCleanup: null,
    formRecData: {},
    async openModalRecMed(idrecetamedica) {
      this.isModalRecMedOpen = true
      const response = await fetch(`/api/recetamed/${idrecetamedica}`);
      const RecetaData = await response.json();
      this.formRecData = RecetaData;
      this.formRecData.idrecetamedica = idrecetamedica;

      const form = document.getElementById('editarRecForm');
      form.action = `/editarRecetaMed/${idrecetamedica}`;
    },
    closeModalRecMed() {
      this.isModalRecMedOpen = false
      this.trapCleanup()
    }
  } 
}
function confirmarEliminacion(idpaciente) {
  const mensaje = "¿Estás seguro de que deseas eliminar este paciente?";
  if (window.confirm(mensaje)) {
      // El usuario hizo clic en "Aceptar", redirige a la URL de eliminación
      window.location.href = "eliminarPaciente/id".replace("id", idpaciente);
  } else {
      // El usuario hizo clic en "Cancelar", no se realiza ninguna acción
  }
}
function confirmarEliminacionMed(idmedico) {
  const mensaje = "¿Estás seguro de que deseas eliminar este médico?";
  if (window.confirm(mensaje)) {
      // El usuario hizo clic en "Aceptar", redirige a la URL de eliminación
      window.location.href = "eliminarMedico/id".replace("id", idmedico);
  } else {
      // El usuario hizo clic en "Cancelar", no se realiza ninguna acción
  }
}
function confirmarEliminacionDiag(iddiagnostico) {
  const mensaje = "¿Estás seguro de que deseas eliminar este diagnóstico?";
  if (window.confirm(mensaje)) {
      // El usuario hizo clic en "Aceptar", redirige a la URL de eliminación
      window.location.href = "eliminarDiagnostico/id".replace("id", iddiagnostico);
  } else {
      // El usuario hizo clic en "Cancelar", no se realiza ninguna acción
  }
}
function confirmarEliminacionReceta(idrecetamedica) {
  const mensaje = "¿Estás seguro de que deseas eliminar esta receta médica?";
  if (window.confirm(mensaje)) {
      // El usuario hizo clic en "Aceptar", redirige a la URL de eliminación
      window.location.href = "eliminarReceta/id".replace("id", idrecetamedica);
  } else {
      // El usuario hizo clic en "Cancelar", no se realiza ninguna acción
  }
}