from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('',views.inicio),
    path('inicio.html',views.inicio),
    path('contacto.html',views.contacto),
    path('historia.html',views.historia),
    path('otros.html',views.otros),

    path('login',views.index),
    path('salir/', views.cerrarsesion, name="salir"),

    path('index.html',views.index),
    path('medicos.html',views.medicos),
    path('recetas_medicas.html',views.recetas_medicas),
    path('diagnosticos.html',views.diagnostico),
    
    path('form_agregar_paciente.html',views.form_pacientes),
    path('form_agregar_medico.html',views.form_medicos),
    path('form_agregar_diagnosticos.html',views.form_diagnosticos),
    path('form_agregar_recetamed.html',views.form_receta_medica),

    path('api/paciente/<int:idpaciente>', views.obtener_datos_paciente),
    path('registrarPaciente/',views.registrarPaciente),
    path('editarPaciente/<int:idpaciente>', views.editarPaciente),
    path('eliminarPaciente/<int:idpaciente>', views.eliminarPaciente),
    
    path('api/medico/<int:idmedico>', views.obtener_datos_medico),
    path('registrarMedico/',views.registrarMedico),
    path('editarMedico/<int:idmedico>', views.editarMedico),
    path('eliminarMedico/<int:idmedico>', views.eliminarMedico),
    
    path('api/diagnostico/<int:iddiagnostico>', views.obtener_datos_diagnostico),
    path('registrarDiagnostico', views.registrarDiagnostico, name='registrar-diagnostico'),
    path('editarDiagnostico/<int:iddiagnostico>', views.editar_diagnostico,name="editarDiagnostico"),
    path('eliminarDiagnostico/<int:iddiagnostico>', views.eliminarDiagnostico),

    path('api/recetamed/<int:idrecetamedica>', views.obtener_desc_recetas),
    path('registrarReceta',views.registrarRecetaMedica, name="registrar-receta"),
    path('editarRecetaMed/<int:idrecetamedica>', views.editarRecetaMedica,name="editarReceta"),
    path('eliminarReceta/<int:idrecetamedica>', views.eliminarReceta),
    
]


   