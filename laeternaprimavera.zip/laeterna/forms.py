from django import forms
from .models import Diagnostico
from .models import Medico
from .models import Paciente
from .models import RecetaMedica

#----------------- FORMULARIO PARA REGISTRAR DIAGNOSTICOS ------------------------------------------
class DiagnosticoForm(forms.ModelForm):

    class Meta:
        model = Diagnostico
        fields = ['idmedico', 'idpaciente', 'diagnostico']

    idmedico = forms.ModelChoiceField(
        label="Médico",
        queryset=Medico.objects.all(),
        empty_label="Selecciona un médico",
        widget=forms.Select(attrs={'class': 'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-textarea focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray'})
    )

    idpaciente = forms.ModelChoiceField(
        label="Paciente",
        queryset=Paciente.objects.all(),
        empty_label="Selecciona un paciente",
        widget=forms.Select(attrs={'class': 'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-textarea focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray'})
    )

    diagnostico = forms.CharField(
        label="Diagnóstico",
        widget=forms.Textarea(attrs={'rows':4, 'class':'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-textarea focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray', 'placeholder': 'Ingresa el diagnóstico aquí...'})
    )

#----------------- FORMULARIO PARA REGISTRAR RECETAS MÉDICAS ------------------------------------------

class RecetaMedForm(forms.ModelForm):

    class Meta:
        model = RecetaMedica
        fields = ['idmedico', 'idpaciente', 'iddiagnostico', 'descripcion']

    idmedico = forms.ModelChoiceField(
        label="Médico",
        queryset=Medico.objects.all(),
        empty_label="Selecciona un médico",
        widget=forms.Select(attrs={'class': 'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-textarea focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray'})
    )

    idpaciente = forms.ModelChoiceField(
        label="Paciente",
        queryset=Paciente.objects.all(),
        empty_label="Selecciona un paciente",
        widget=forms.Select(attrs={'class': 'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-textarea focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray'})
    )

    iddiagnostico = forms.ModelChoiceField(
        label="Diagnóstico",
        queryset=Diagnostico.objects.all(),
        empty_label="Selecciona un diagnóstico",
        widget=forms.Select(attrs={'class': 'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-textarea focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray'})
    )

    descripcion = forms.CharField(
        label="Descripción",
        widget=forms.Textarea(attrs={'rows':4, 'class':'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-textarea focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray', 'placeholder': 'Ingresa la receta aquí...'})
    )


#----------------- FORMULARIO PARA EDITAR DIAGNÓSTICOS ------------------------------------------

class DiagnosticoEditForm(forms.ModelForm):
    class Meta:
        model = Diagnostico
        fields = ['idmedico', 'idpaciente', 'iddiagnostico', 'diagnostico']

    idmedico = forms.ModelChoiceField(
        queryset=Medico.objects.all(),
        label="Médico",
        empty_label="Selecciona un médico",
        widget=forms.Select(attrs={
            'class': 'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-select focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray'
        })
    )

    idpaciente = forms.ModelChoiceField(
        queryset=Paciente.objects.all(),
        label="Paciente",
        empty_label="Selecciona un paciente",
        widget=forms.Select(attrs={
            'class': 'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-select focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray'
        })
    )

    diagnostico = forms.CharField(
        label="Descripción del diagnóstico",
        widget=forms.Textarea(attrs={
            'rows': 4,
            'class': 'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-textarea focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray',
            'placeholder': 'Ingresa el diagnóstico aquí...',
            'x-model':'formDiagData.diagnostico'
        })
    )

#----------------- FORMULARIO PARA EDITAR RECETAS MÉDICAS ------------------------------------------

class RecetaMedicaEditForm(forms.ModelForm):
    class Meta:
        model = RecetaMedica
        fields = ['idmedico', 'idpaciente', 'iddiagnostico', 'descripcion']

    idmedico = forms.ModelChoiceField(
        queryset=Medico.objects.all(),
        label="Médico",
        empty_label="Selecciona un médico",
        widget=forms.Select(attrs={
            'class': 'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-select focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray'
        })
    )

    idpaciente = forms.ModelChoiceField(
        queryset=Paciente.objects.all(),
        label="Paciente",
        empty_label="Selecciona un paciente",
        widget=forms.Select(attrs={
            'class': 'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-select focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray'
        })
    )

    iddiagnostico = forms.ModelChoiceField(
        queryset=Diagnostico.objects.all(),
        label="Diagnóstico",
        empty_label="Selecciona un diagnóstico",
        widget=forms.Select(attrs={
            'class': 'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-select focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray'
        })
    )

    descripcion = forms.CharField(
        
        label="Descripción",
        widget=forms.Textarea(attrs={
            'value':RecetaMedica.descripcion,
            'rows': 4,
            'class': 'block w-full mt-2 text-sm dark:text-gray-300 dark:border-gray-600 dark:bg-gray-700 form-textarea focus:border-purple-400 focus:outline-none focus:shadow-outline-purple dark:focus:shadow-outline-gray',
            'placeholder': 'Ingresa la prescripción médica aquí...'
        })
    )