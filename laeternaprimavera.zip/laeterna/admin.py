from django.contrib import admin
from .models import Medico
from .models import Paciente 
from .models import Diagnostico
from .models import RecetaMedica

# Register your models here.

admin.site.register(Medico)
admin.site.register(Paciente)
admin.site.register(Diagnostico)
admin.site.register(RecetaMedica)