from django.db import models
from django.db.models.fields import CharField, DateField
import bcrypt
from django import forms

class Medico(models.Model):
    idmedico = models.AutoField(primary_key=True)
    nombres = models.CharField(max_length=45)
    apellidos = models.CharField(max_length=45)
    num_colegiado = models.CharField(max_length=9)
    especialidad = models.CharField(max_length=45)
    

    def __str__(self):
        return f"{self.nombres} {self.apellidos}"
    
    def to_dict(self):
        return {
            'idmedico': self.idmedico,
            'nombres': self.nombres,
            'apellidos': self.apellidos,
            'num_colegiado': self.num_colegiado,
            'especialidad': self.especialidad,
            'num_tel' : self.num_tel,
        }

class Paciente(models.Model):
    idpaciente = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=45)
    apellido = models.CharField(max_length=45)
    dpi = models.CharField(max_length=15)
    fecha_nacimiento = models.DateField()
    direccion = models.CharField(max_length=50)
    razon_visita = models.CharField(max_length=255)
    num_tel = models.CharField(max_length=16)
    fecha_creacion = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.nombre} {self.apellido}"
    
    def to_dict(self):
        return {
            'idpaciente': self.idpaciente,
            'nombre': self.nombre,
            'apellido': self.apellido,
            'dpi': self.dpi,
            'direccion': self.direccion,
            'razon_visita': self.razon_visita,
            'num_tel': self.num_tel,
            'fecha_creacion' : self.fecha_creacion
        }

class Diagnostico(models.Model):
    iddiagnostico = models.AutoField(primary_key=True)
    idmedico = models.ForeignKey(Medico, on_delete=models.CASCADE, db_column='idmedico')
    idpaciente = models.ForeignKey(Paciente, on_delete=models.CASCADE, db_column='idpaciente')
    diagnostico = models.TextField()
    fecha = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Médico: {self.idmedico} Desc: {self.diagnostico}"

class RecetaMedica(models.Model):
    idrecetamedica = models.AutoField(primary_key=True)
    idmedico = models.ForeignKey(Medico, on_delete=models.CASCADE, db_column='idrol')
    idpaciente = models.ForeignKey(Paciente, on_delete=models.CASCADE, db_column='idpaciente')
    iddiagnostico = models.ForeignKey(Diagnostico, on_delete=models.CASCADE, db_column='iddiagnostico')
    descripcion = models.TextField()
    fecha = models.DateTimeField(auto_now_add=True)  

    def __str__(self):
        return f"Receta Médica #{self.idrecetamedica}"
