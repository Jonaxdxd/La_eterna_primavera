from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.urls import reverse
from django.utils import timezone  
from .models import Medico, Paciente, Diagnostico, RecetaMedica
from datetime import datetime
from django.http import JsonResponse, HttpResponse, Http404
from django.shortcuts import get_object_or_404
from django.contrib.auth import logout
from django.contrib import messages
from .forms import DiagnosticoForm
from .forms import RecetaMedForm
from .forms import DiagnosticoEditForm
from .forms import RecetaMedicaEditForm


# Create your views here.

def inicio(request):
    return render(request, 'inicio.html')

def contacto(request):
    return render(request, 'contacto.html')

def historia(request):
    return render(request, 'historia.html')

def otros(request):
    return render(request, 'otros.html')

def error_404(request, exception):
    return render(request, '404.html', status=404)

@login_required
def cerrarsesion(request):
    logout(request)
    return redirect('/')

@login_required
def index(request):
    Listapacientes = Paciente.objects.all() 
    return render(request, 'index.html', {"pacientes": Listapacientes})

@login_required
def medicos(request):
    Listamedicos = Medico.objects.all() 
    return render(request, 'medicos.html',{"medicos": Listamedicos})

@login_required
def diagnostico(request):
    Listadiagnostico = Diagnostico.objects.all() 
    editform = DiagnosticoEditForm()
    return render(request, 'diagnosticos.html',{"diagnosticos": Listadiagnostico,"editform": editform})

@login_required
def recetas_medicas(request):
    Listarecetas = RecetaMedica.objects.all()
    editrecform = RecetaMedicaEditForm()

    return render(request, 'recetas_medicas.html', {
        'editrecform': editrecform,
        'recetas': Listarecetas
    })
    
@login_required
def form_pacientes(request):
    return render(request, 'form_agregar_paciente.html')

@login_required
def form_medicos(request):
    return render(request, 'form_agregar_medico.html')

@login_required
def form_diagnosticos(request):
    form = DiagnosticoForm()
    return render(request,'form_agregar_diagnosticos.html', {'form': form})


@login_required
def form_receta_medica(request):
    form = RecetaMedForm()
    return render(request, 'form_agregar_recetamed.html',{'form': form})

@login_required
def obtener_datos_paciente(request, idpaciente):
    paciente = Paciente.objects.get(idpaciente=idpaciente)
    data = {
        'idpaciente': paciente.idpaciente,
        'nombre': paciente.nombre,
        'apellido': paciente.apellido,
        'dpi': paciente.dpi,
        'fecha_nacimiento': paciente.fecha_nacimiento,
        'direccion': paciente.direccion,
        'razon_visita': paciente.razon_visita,
        'num_tel': paciente.num_tel,
        'fecha_creacion': paciente.fecha_creacion,
    }
    return JsonResponse(data)

@login_required
def registrarPaciente(request):
    nombre = request.POST['txtnombre']
    apellido = request.POST['txtapellido']
    dpi = request.POST['txtdpi']
    fecha_nacimiento = request.POST['fecha_nacimiento']
    direccion = request.POST['txtdireccion']
    razon_visita = request.POST['txtrazon_visita']
    num_tel = request.POST['num_tel']
    fecha_creacion = datetime.now()

    paciente = Paciente.objects.create(
        nombre=nombre, apellido=apellido, dpi=dpi, fecha_nacimiento=fecha_nacimiento, direccion=direccion, razon_visita=razon_visita, num_tel=num_tel, fecha_creacion=fecha_creacion
    )
    messages.success(request,"Paciente Registrado Correctamente")

    return redirect('/index.html')

@login_required
def editarPaciente(request,idpaciente):
    nombre = request.POST['nombre']
    apellido = request.POST['apellido']
    dpi = request.POST['dpi']
    fecha_nacimiento = request.POST['fecha_nacimiento']
    direccion = request.POST['direccion']
    razon_visita = request.POST['razon_visita']
    num_tel = request.POST['num_tel']
    fecha_creacion = request.POST['fecha_creacion']

    paciente = Paciente.objects.get(idpaciente=idpaciente)
    paciente.nombre = nombre
    paciente.apellido = apellido
    paciente.dpi = dpi
    paciente.fecha_nacimiento = fecha_nacimiento
    paciente.direccion = direccion
    paciente.razon_visita = razon_visita
    paciente.num_tel = num_tel
    paciente.fecha_creacion = fecha_creacion
    paciente.save()
    messages.success(request,"Paciente Actualizado Correctamente")

    return redirect('/index.html')

@login_required
def eliminarPaciente(request, idpaciente):
    paciente = Paciente.objects.get(idpaciente=idpaciente)
    paciente.delete()
    messages.success(request,"Paciente Eliminado Correctamente")

    return redirect('/index.html')

@login_required
def obtener_datos_medico(request, idmedico):
    medico = Medico.objects.get(idmedico=idmedico)
    data = {
        'idmedico': medico.idmedico,
        'nombres': medico.nombres,
        'apellidos': medico.apellidos,
        'num_colegiado': medico.num_colegiado,
        'especialidad': medico.especialidad
    }
    return JsonResponse(data)

@login_required
def registrarMedico(request):
    nombres = request.POST['nombres']
    apellidos = request.POST['apellidos']
    num_colegiado = request.POST['num_colegiado']
    especialidad = request.POST['especialidad']

    medico = Medico.objects.create(
        nombres=nombres, apellidos=apellidos, num_colegiado=num_colegiado, especialidad=especialidad)
    messages.success(request,"Médico Registrado Correctamente")
    return redirect('/medicos.html')

@login_required
def editarMedico(request,idmedico):
    nombres = request.POST['nombres']
    apellidos = request.POST['apellidos']
    num_colegiado = request.POST['num_colegiado']
    especialidad = request.POST['especialidad']

    medico = Medico.objects.get(idmedico=idmedico)
    medico.nombres = nombres
    medico.apellidos = apellidos
    medico.num_colegiado = num_colegiado
    medico.especialidad = especialidad
    medico.save()
    messages.success(request,"Médico Actualizado Correctamente")

    return redirect('/medicos.html')

@login_required
def eliminarMedico(request, idmedico):
    medico = Medico.objects.get(idmedico=idmedico)
    medico.delete()
    messages.success(request,"Médico Eliminado Correctamente")

    return redirect('/medicos.html')

@login_required
def obtener_datos_diagnostico(request, iddiagnostico):
    diag = Diagnostico.objects.get(iddiagnostico=iddiagnostico)
    data = {
        'iddiagnostico': diag.iddiagnostico,
        'diagnostico': diag.diagnostico,
        'idmedico' : f"{diag.idmedico.nombres} {diag.idmedico.apellidos}",
        'idpaciente' : f"{diag.idpaciente.nombre} {diag.idpaciente.apellido}"
    }
    return JsonResponse(data)


@login_required
def registrarDiagnostico(request):
    if request.method == 'POST':
        form = DiagnosticoForm(request.POST)
        if form.is_valid():
            diagnostico = form.save(commit=False)
            diagnostico.fecha = datetime.now()
            diagnostico.save()
            messages.success(request, "Diagnóstico registrado correctamente")

        return redirect('diagnosticos.html')
    else:
        form = DiagnosticoForm()
    return render(request, 'diagnosticos.html', {'form': form})

def editar_diagnostico(request, iddiagnostico):
    diagnostico = Diagnostico.objects.get(iddiagnostico=iddiagnostico)

    if request.method == 'POST':
        editform = DiagnosticoEditForm(request.POST, instance=diagnostico)
        if editform.is_valid():
            editform.save()
            messages.success(request,"Diagnóstico Editado Correctamente")
            return redirect('/diagnosticos.html')
            
    else:
        editform = DiagnosticoEditForm(instance=diagnostico)
        return render(request, 'diagnosticos.html', {'editform': editform, 'diagnostico': diagnostico})

@login_required
def eliminarDiagnostico(request, iddiagnostico):
    diagnostico = Diagnostico.objects.get(iddiagnostico=iddiagnostico)
    diagnostico.delete()
    messages.success(request,"Diagnóstico Eliminado Correctamente")

    return redirect('/diagnosticos.html')

@login_required
def obtener_desc_recetas(request, idrecetamedica):
    receta = RecetaMedica.objects.get(idrecetamedica=idrecetamedica)
    data = {
        'idrecetamedica': receta.idrecetamedica,
        'descripcion': receta.descripcion
    }
    return JsonResponse(data)

@login_required
def registrarRecetaMedica(request):
    if request.method == 'POST':
        form = RecetaMedForm(request.POST)
        if form.is_valid():
            receta = form.save(commit=False)
            receta.fecha = datetime.now()
            receta.save()
            messages.success(request, "Receta registrada correctamente")

        return redirect('recetas_medicas.html')
    else:
        form = RecetaMedForm()
    return render(request, 'recetas_medicas.html', {'form': form})

# Vistas
def editarRecetaMedica(request, idrecetamedica):
    recetamed = RecetaMedica.objects.get(idrecetamedica=idrecetamedica)

    if request.method == 'POST':
        editrecform = RecetaMedicaEditForm(request.POST, instance=recetamed)
        if editrecform.is_valid():
            editrecform.save()
            messages.success(request, "Receta Editada Correctamente")
            return redirect('/recetas_medicas.html')
    else:
        editrecform = RecetaMedicaEditForm(instance=recetamed)  # Pasar la instancia de recetamed
        return render(request, 'recetas_medicas.html', {'editrecform': editrecform, 'recetamed': recetamed})

@login_required
def eliminarReceta(request, idrecetamedica):
    recetamed = RecetaMedica.objects.get(idrecetamedica=idrecetamedica)
    recetamed.delete()
    messages.success(request,"Receta Médica Eliminada")
    return redirect('/recetas_medicas.html')
